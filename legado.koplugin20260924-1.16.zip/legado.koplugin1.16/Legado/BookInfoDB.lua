local SQ3 = require("lua-ljsqlite3/init")
local UIManager = require("ui/uimanager")
local logger = require("logger")
local dbg = require("dbg")
local Device = require("device")
local util = require("util")
local H = require("Legado/Helper")
local FS = require("Legado.Helper.FS")

if not dbg.log then
    dbg.log = logger.dbg
end

local custom_type_variable = {}
local M = {
    dbPath = nil,
    db_conn = nil,
    isConnected = false,
    dbCreated = false,
    in_transaction = false
}

local function custom_concat(tbl, sep)
    sep = sep or ""
    local result = {}

    for i, v in ipairs(tbl) do
        if v == nil then
            result[i] = "nil"
        elseif type(v) == "table" then

            result[i] = "{" .. custom_concat(v, ",") .. "}"
        else
            result[i] = tostring(v)
        end
    end

    return table.concat(result, sep)
end

local BOOKINFO_DB_VERSION = 20250328

local BOOKINFO_DB_SCHEMA = [[

CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,      
    bookShelfId TEXT NOT NULL,                  
    bookCacheId TEXT NOT NULL,                  
    name TEXT NOT NULL,                         
    author TEXT NOT NULL,                       
    bookUrl TEXT NOT NULL,                      
    origin TEXT NOT NULL,                       
    originName TEXT NOT NULL,                   
    originOrder INTEGER DEFAULT 0,              

    
    durChapterIndex INTEGER DEFAULT 0,          
    durChapterPos INTEGER DEFAULT 0,            
    durChapterTime INTEGER DEFAULT 0,           
    durChapterTitle TEXT DEFAULT '',            

    
    intro TEXT,                                 
    kind TEXT,                                   
    totalChapterNum INTEGER DEFAULT 0,          
    btype INTEGER NOT NULL DEFAULT 0,            
    wordCount TEXT,                              
    coverUrl TEXT,                              

    
    cacheExt TEXT DEFAULT NULL,                              
    sortOrder INTEGER DEFAULT 1,                
    isEnabled INTEGER DEFAULT 1,
    lastUpdated INTEGER DEFAULT (strftime('%s', 'now')),
    UNIQUE (bookShelfId, bookCacheId) 
);


CREATE TABLE IF NOT EXISTS task_locks (
    lock_name TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL DEFAULT 'main',
    acquire_time INTEGER DEFAULT (CAST(strftime('%s', 'now') AS INTEGER)),
    expire_time INTEGER NOT NULL
);


CREATE TABLE IF NOT EXISTS chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,       
    bookCacheId TEXT NOT NULL,                    
    chapterIndex INTEGER NOT NULL,    
    title TEXT DEFAULT '',             
    
    isVolume INTEGER DEFAULT 0, 
    
    
    isRead INTEGER DEFAULT 0,       
    cacheFilePath TEXT DEFAULT NUll,   
    content TEXT DEFAULT NUll,          
    lastUpdated INTEGER DEFAULT 0, 

    
    UNIQUE (bookCacheId, chapterIndex)
);

CREATE INDEX IF NOT EXISTS idx_book_main ON books (bookShelfId, bookCacheId, isEnabled);
CREATE INDEX IF NOT EXISTS idx_books_bookCacheId_isenabled ON books (bookCacheId, isEnabled);
CREATE INDEX IF NOT EXISTS idx_chapter_basic ON chapters (bookCacheId, chapterIndex);
CREATE INDEX IF NOT EXISTS idx_book_sortorder_Lastread ON books ( sortOrder );
CREATE INDEX IF NOT EXISTS idx_books_bookshelfid_isenabled_sortorder ON books (bookShelfId, isEnabled, sortOrder);
CREATE INDEX IF NOT EXISTS idx_chapters_chapterindex ON chapters (chapterIndex);
CREATE INDEX IF NOT EXISTS idx_chapters_cachefilepath ON chapters (cacheFilePath);
CREATE INDEX IF NOT EXISTS idx_chapters_bookcacheid_lastupdated ON chapters (bookCacheId, lastUpdated);
CREATE INDEX IF NOT EXISTS idx_task_locks_expire ON task_locks (expire_time);
]]

-- 查询字段的顺序必须与映射函数的 row[x] 索引完全一致
local COLS_BOOK_FULL = "bookCacheId, name, author, bookUrl, origin, originName, originOrder, durChapterIndex, durChapterPos, durChapterTime, durChapterTitle, wordCount, intro, totalChapterNum, kind, sortOrder, cacheExt, coverUrl"
local function _mapBookRow(row, bookShelfId)
    if not row then return nil end
    return {
        book_self_id = bookShelfId,
        cache_id = row[1],
        name = row[2],
        author = row[3],
        bookUrl = row[4],
        origin = row[5],
        originName = row[6],
        originOrder = tonumber(row[7]) or 0,
        durChapterIndex = tonumber(row[8]) or 0,
        durChapterPos = tonumber(row[9]) or 0,
        durChapterTime = tonumber(row[10]) or 0,
        durChapterTitle = row[11] or "",
        wordCount = row[12] or "",
        intro = row[13] or "",
        totalChapterNum = tonumber(row[14]) or 0,
        kind = row[15] or "",
        sortOrder = tonumber(row[16]) or 0,
        cacheExt = row[17],
        coverUrl = row[18]
    }
end

local COLS_CHAPTER_FULL = "c.chapterIndex, c.title, c.isRead, c.cacheFilePath, b.name, b.author, b.bookUrl, b.durChapterIndex, b.durChapterTime, b.totalChapterNum, b.cacheExt, b.origin"
local function _mapChapterRow(row, bookCacheId)
    if not row then return nil end
    return {
        book_cache_id = bookCacheId,
        chapters_index = tonumber(row[1]) or 0,
        title = row[2] or "",
        isRead = row[3] == 1,
        cacheFilePath = row[4],
        isDownLoaded = not not row[4],
        name = row[5],
        author = row[6],
        bookUrl = row[7],
        durChapterIndex = tonumber(row[8]) or 0,
        durChapterTime = tonumber(row[9]) or 0,
        totalChapterNum = tonumber(row[10]) or 0,
        cacheExt = row[11],
        origin = row[12]
    }
end

local COLS_BOOK_UI = "bookCacheId, name, author, originName, coverUrl"
local function _mapBookRowUI(row)
    if not row then return nil end
    return {
        cache_id = row[1],
        name = row[2],
        author = row[3],
        originName = row[4],
        cover = row[5],
    }
end

local COLS_CHAPTER_UI = "c.chapterIndex, c.title, c.isRead, c.cacheFilePath, b.durChapterIndex"
local function _mapChapterRowUI(row)
    if not row then return nil end
    return {
        chapters_index = tonumber(row[1]) or 0,
        title = row[2] or "",
        isRead = row[3] == 1,
        isDownLoaded = not not row[4],
        durChapterIndex = tonumber(row[5]) or 0,
        cacheFilePath = row[4]
    }
end

local COLS_CHAPTER_NOT_DOWNLOADED = "c.chapterIndex, c.title, b.bookUrl, b.name, b.origin"
local function _mapChapterNotDownloadedRow(row, bookCacheId)
    if not row then return nil end
    return {
        book_cache_id = bookCacheId,
        chapters_index = tonumber(row[1]) or 0,
        title = row[2],
        bookUrl = row[3],
        name = row[4],
        origin = row[5],
    }
end

function M:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    if o.init then
        o:init()
    end
    return o
end

function M:init()
    self:_initDB()
end

function M.nil_object()
    return setmetatable({
        __type_ext = 'nil',
        [1] = 'nil'

    }, {
        __tostring = function()
            return "nil"
        end
    })
end

function M:blob_object(byte_array, size)
    return setmetatable({
        __type_ext = 'blob',
        __ext_size = size,
        [1] = byte_array
    }, {
        __tostring = function()
            return "blob"
        end
    })
end

function M:_setJournalMode()
    local mode = Device:canUseWAL() and "WAL" or "TRUNCATE"
    local success, err = pcall(function()
        self.db:exec("PRAGMA journal_mode=" .. mode .. ";")
    end)
    if success then
        dbg.v("Database journal mode set to: " .. mode)
    else
        dbg.log("Failed to set journal mode. Error: " .. tostring(err))
    end

end

function M:_openDB()
    if self.isConnected and self.db then

        return self.db
    end
    if not self.dbPath then
        error('Variable not set db path!')
    end
    local success, db = pcall(function()
        return SQ3.open(self.dbPath)
    end)
    if not success or not db then
        dbg.log("Failed to open database at: " .. self.dbPath)
        error("Failed to open database at: " .. self.dbPath)
        return nil
    end

    self.db = db
    self.isConnected = true
    self.in_transaction = false

    self.db:set_busy_timeout(5000)

    dbg.v("Database opened successfully at: " .. self.dbPath)

    self:_setJournalMode()

    return self.db
end

function M:_initDB(is_repair)
    local db
    local success, rc = pcall(function()
        db = self:_openDB()
        db:exec(string.format("PRAGMA user_version=%d;", BOOKINFO_DB_VERSION))
        return db:exec(BOOKINFO_DB_SCHEMA)
    end)
    if success and rc == SQ3.OK then
        dbg.v("Database schema initialized successfully.")
        self.dbCreated = true
        self:closeDB()
    else
        dbg.log("Failed to initialize database schema. Return code: " .. tostring(rc))
        local last_backup_db = self.dbPath .. ".bak"
        local has_backup = util.fileExists(last_backup_db)
        if has_backup then
            FS.copyFileFromTo(last_backup_db, self.dbPath)
            util.removeFile(last_backup_db)
            dbg.log("The backup database has been restored")
        else
            if util.fileExists(self.dbPath) then
                util.removeFile(self.dbPath)
                dbg.log("Removed corrupt database file")
            end
        end
        if not is_repair then
            self:closeDB()
            self:_initDB(true)
        end
    end
end

function M:closeDB()
    if not self.isConnected or not self.db then
        return
    end

    local success, err = pcall(function()
        return self.db:close()
    end)
    if not success then
        dbg.log("closing database: " .. tostring(err))
    end
    self.db = nil
    self.isConnected = nil
end

function M:getDB()

    if not util.fileExists(self.dbPath) then
        self:_initDB()
    end
    if not self.isConnected or not self.db then
        return self:_openDB()
    end
    return self.db
end

function M:transaction(write_func, opts)
    return function(...)
        local conn = self:getDB()
        opts = opts or {}
        local savepoint_name
        local use_savepoint = opts.enable_savepoint and self.in_transaction

        if use_savepoint then
            savepoint_name = string.format("sp_%08x", math.random(0x7fffffff))
            local savepoint_sql = string.format("SAVEPOINT %s", savepoint_name)
            conn:exec(savepoint_sql)
        else

            local txn_type = opts.transaction_type or "IMMEDIATE"
            conn:exec(string.format("BEGIN %s TRANSACTION", txn_type))
            self.in_transaction = true
        end

        local ok, result = xpcall(function(...)
            return write_func(...)
        end, function(err)

            return debug.traceback(tostring(err), 2)
        end, ...)

        if use_savepoint then
            if ok then
                conn:exec(string.format("RELEASE %s", savepoint_name))
            else
                pcall(conn.exec, conn, string.format("ROLLBACK TO %s", savepoint_name))
            end
        else
            local status = ok and "COMMIT" or "ROLLBACK"
            pcall(conn.exec, conn, status)
            self.in_transaction = false
        end

        if not ok then
            error(result, 0)

        end
        return result
    end
end

local function bool_to_number(bool_value)

    return bool_value and 1 or 0
end

local function validate_data_list(data_list)
    if type(data_list) ~= "table" or #data_list == 0 then
        error("The data list must be a non-empty array")
    end
end

local function adapt_value(v)
    if type(v) == "boolean" then
        return bool_to_number(v)
    elseif type(v) == "table" and v.__type_ext == 'blob' then
        return SQ3.blob(v[1], v.__ext_size)
    elseif type(v) == "table" and v.__type_ext == 'nil' then
        return nil
    end
    return v
end

local function validate_param_type(v, pos)
    local t = type(v)
    if not (t == "nil" or t == "number" or t == "string" or t == 'boolean' or (t == "table" and v.__type_ext)) then
        error(string.format("Illegal parameter type %s (position %d)", t, pos))
    end
end

function M:batch_insert(sql_template, data_list, batch_size)
    batch_size = batch_size or 500
    validate_data_list(data_list)

    local _, param_count = sql_template:gsub("%?", "")

    local function process_batch(batch_data)
        return self:transaction(function()
            local stmt = self:getDB():prepare(sql_template)

            for _, params in ipairs(batch_data) do
                for i = 1, param_count do
                    stmt:bind1(i, adapt_value(params[i]))
                end

                local step_ok, step_err = pcall(stmt.step, stmt)
                if not step_ok then
                    error(string.format("Step execution failed:%s\n Parameters:%s", step_err,
                        custom_concat(params, ", ")))
                end
                stmt:reset()
            end

            stmt:clearbind():close()
        end, {
            enable_savepoint = true
        })()
    end

    if batch_size <= 0 or #data_list <= batch_size then
        return process_batch(data_list)
    end

    local total = #data_list
    for i = 1, total, batch_size do
        local batch = {}
        for j = i, math.min(i + batch_size - 1, total) do
            table.insert(batch, data_list[j])
        end
        process_batch(batch)
    end
end

local _write_ops = {
    INSERT = true,
    UPDATE = true,
    DELETE = true,
    REPLACE = true,
    ALTER = true,
    DROP = true
}

function M:execute(sql, params, options)

    params = params or {}
    options = options or {}
    if type(params) ~= "table" then
        params = {params}
    end

    local op = sql:match("^%s*(%w+)") or "UNKNOWN"

    op = op:upper()
    local is_write = _write_ops[op]

    local placeholder_count = select(2, sql:gsub("%?", "%?"))
    if placeholder_count ~= #params then
        error(string.format(
            "The number of parameters does not match (SQL has %d placeholders, %d parameters are passed in, parameter %s)",
            placeholder_count, #params, custom_concat(params, ", ")))
    end

    local conn = self:getDB()

    if not conn then
        error("Database not connected")
    end

    local stmt, err = conn:prepare(sql)
    if not stmt then
        error("SQL预处理失败: " .. tostring(err))
    end

    for i, v in ipairs(params) do
        validate_param_type(v, i)

        stmt:bind1(i, adapt_value(v))

    end

    if options.return_stmt then
        return stmt
    end

    local ok, ret = pcall(function()
        if is_write then
            stmt:step()

            return {
                last_insert_rowid = conn:rowexec("SELECT last_insert_rowid() AS id") or 0,
                changes = conn:rowexec("SELECT changes() AS count") or 0
            }
        else

            local result = {}
            local row = {}

            local i = 1
            for row in stmt:rows() do

                if row == nil then
                    break
                end

                result[i] = row
                i = i + 1

            end

            return result
        end
    end)

    stmt:clearbind():reset()

    if not ok then
        error(string.format("SQL Execution failed\nStatement: %s\nError: %s", sql, ret))
    else

        return ret
    end
end

function M:safe_rows(sql, params, fetch_size)
    fetch_size = fetch_size or 100
    local stmt = self:execute(sql, params, {
        return_stmt = true
    })

    return function()
        local batch = {}
        for _ = 1, fetch_size do
            local row = stmt:step()
            if not row then
                break
            end
            table.insert(batch, row)
        end

        if #batch == 0 then
            stmt:clearbind():reset()
            return nil
        end
        stmt:clearbind():reset()
        return batch
    end
end

function M:upsertBooks(bookShelfId, legado_data, isUpdate)
    if not H.is_str(bookShelfId) or not H.is_tbl(legado_data) then
        dbg.log('BookInfoDB:upsertBooks Incorrect input parameters')
        return false
    end

    local sql_stmt = [[
    INSERT INTO books (
    bookShelfId, bookCacheId, name, author, bookUrl, origin, originName, originOrder, 
    durChapterIndex, durChapterPos, durChapterTime, durChapterTitle, wordCount, 
    coverUrl, intro, totalChapterNum, btype, isEnabled, kind
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(bookShelfId, bookCacheId) DO UPDATE SET
    name = CASE WHEN excluded.name != books.name THEN excluded.name ELSE books.name END,
    author = CASE WHEN excluded.author != books.author THEN excluded.author ELSE books.author END,
    bookUrl = CASE WHEN excluded.bookUrl != books.bookUrl THEN excluded.bookUrl ELSE books.bookUrl END,
    origin = CASE WHEN excluded.origin != books.origin THEN excluded.origin ELSE books.origin END,
    originName = CASE WHEN excluded.originName != books.originName THEN excluded.originName ELSE books.originName END,
    originOrder = CASE WHEN excluded.originOrder != books.originOrder THEN excluded.originOrder ELSE books.originOrder END,
    durChapterIndex = CASE WHEN excluded.durChapterIndex != books.durChapterIndex THEN excluded.durChapterIndex ELSE books.durChapterIndex END,
    durChapterPos = CASE WHEN excluded.durChapterPos != books.durChapterPos THEN excluded.durChapterPos ELSE books.durChapterPos END,
    durChapterTime = CASE WHEN excluded.durChapterTime != books.durChapterTime THEN excluded.durChapterTime ELSE books.durChapterTime END,
    durChapterTitle = CASE WHEN excluded.durChapterTitle != books.durChapterTitle THEN excluded.durChapterTitle ELSE books.durChapterTitle END,
    wordCount = CASE WHEN excluded.wordCount != books.wordCount THEN excluded.wordCount ELSE books.wordCount END,
    coverUrl = CASE WHEN excluded.coverUrl != books.coverUrl THEN excluded.coverUrl ELSE books.coverUrl END,
    intro = CASE WHEN excluded.intro != books.intro THEN excluded.intro ELSE books.intro END,
    totalChapterNum = CASE WHEN excluded.totalChapterNum != books.totalChapterNum THEN excluded.totalChapterNum ELSE books.totalChapterNum END,
    btype = CASE WHEN excluded.btype != books.btype THEN excluded.btype ELSE books.btype END,
    isEnabled = CASE WHEN excluded.isEnabled != books.isEnabled THEN excluded.isEnabled ELSE books.isEnabled END,
    kind = CASE WHEN excluded.kind != books.kind THEN excluded.kind ELSE books.kind END, 
    lastUpdated = CASE WHEN (
    excluded.bookUrl != books.bookUrl OR
    excluded.wordCount != books.wordCount
) THEN strftime('%s', 'now') ELSE books.lastUpdated END
    ]]

    local batch_data = {}
    for _, item in ipairs(legado_data) do
        local name = H.is_str(item.name) and util.trim(item.name) or ""
        -- 修复进度上传, 作者不处理空格
        local author = tostring(item.author)
        local bookUrl = item.bookUrl
        
        if name ~= "" and H.is_str(bookUrl) then
            -- 修复进度上传, 这里可能导致作者不一致
            -- if author == "" then author = "未知" end
            local show_book_title = ("%s (%s)"):format(name, author)
            item.cache_id = tostring(H.md5(show_book_title))

            table.insert(batch_data, {
                bookShelfId, item.cache_id, name, author, bookUrl, item.origin or "",
                item.originName or "", item.originOrder or 0, item.durChapterIndex or 0,
                item.durChapterPos or 0, item.durChapterTime or 0, item.durChapterTitle or "",
                item.wordCount or "", item.coverUrl or "", item.intro or "", item.totalChapterNum or 0,
                item.type or 0, 1, item.kind or ''
            })
        end
    end

    if #batch_data > 0 then
        if isUpdate ~= true then
            self:disableAllBookShelves()
        end
        self:batch_insert(sql_stmt, batch_data, 0)
    end

    return true
end

function M:getAllBooks(bookShelfId)
    if not H.is_str(bookShelfId) then
        return {}
    end
    local sql_stmt = string.format("SELECT %s FROM books WHERE isEnabled = 1 AND bookShelfId = ?;", COLS_BOOK_FULL)
    local result = self:execute(sql_stmt, {bookShelfId})
    local books = {}
    if result then
        for i = 1, #result do
            books[i] = _mapBookRow(result[i], bookShelfId)
        end
    end

    return books
end

function M:getAllBooksByUI(bookShelfId)
    if not H.is_str(bookShelfId) then
        return {}
    end
    local sql_stmt = string.format("SELECT %s FROM books WHERE isEnabled = 1 AND bookShelfId = ? ORDER BY sortOrder = 0 DESC, sortOrder DESC;", COLS_BOOK_UI)
    local result = self:execute(sql_stmt, {bookShelfId})
    local books = {}
    if result then
        for i = 1, #result do
            books[i] = _mapBookRowUI(result[i])
        end
    end

    return books
end

function M:getBookinfo(bookShelfId, bookCacheId)
    if not H.is_str(bookShelfId) or not H.is_str(bookCacheId) then
        return {}
    end
    local sql_stmt = string.format("SELECT %s FROM books WHERE isEnabled = 1 AND bookShelfId = ? AND bookCacheId = ?;", COLS_BOOK_FULL)
    local result = self:execute(sql_stmt, {bookShelfId, bookCacheId})
    
    if result and #result > 0 then
        return _mapBookRow(result[1], bookShelfId)
    end

    return {}
end

function M:upsertChapters(bookCacheId, chapters)
    if not H.is_str(bookCacheId) or not H.is_tbl(chapters) then
        dbg.log('BookInfoDB:upsertChapters Incorrect input parameters')
        return false
    end

    local sql_stmt = [[
        INSERT INTO chapters (bookCacheId, chapterIndex, title, isVolume)
VALUES (?, ?, ?, ?)
ON CONFLICT(bookCacheId, chapterIndex) DO UPDATE SET
    title = CASE WHEN excluded.title != chapters.title THEN excluded.title ELSE chapters.title END,
    isVolume = CASE WHEN excluded.isVolume != chapters.isVolume THEN excluded.isVolume ELSE chapters.isVolume END;
    ]]

    local batch_data = {}
    for _, chapter in pairs(chapters) do
        if chapter.index ~= nil then

            if not H.is_str(chapter.title) or chapter.title == '' then
                chapter.title = string.format('第%s章', chapter.index)
            end
            table.insert(batch_data, {bookCacheId, chapter.index, chapter.title, chapter.isVolume})

        end
    end

    if #batch_data > 0 then

        self:batch_insert(sql_stmt, batch_data, 0)
    end

    return true
end

function M:getAllChapters(bookCacheId)
    if not H.is_str(bookCacheId) then
        return {}
    end
    local sql_stmt = string.format([[
    SELECT %s 
    FROM chapters AS c INNER JOIN books AS b ON c.bookCacheId = b.bookCacheId 
    WHERE b.isEnabled = 1 AND c.bookCacheId = ? 
    ORDER BY c.chapterIndex ASC;
    ]], COLS_CHAPTER_FULL)

    local result = self:execute(sql_stmt, bookCacheId)
    local chapters = {}
    if result then
        for i = 1, #result do
            chapters[i] = _mapChapterRow(result[i], bookCacheId)
        end
    end

    return chapters
end

function M:getAllChaptersByUI(bookCacheId, is_desc_sort)
    if not H.is_str(bookCacheId) then
        return {}
    end
    local sql_stmt = string.format([[
    SELECT %s 
    FROM chapters AS c INNER JOIN books AS b ON c.bookCacheId = b.bookCacheId 
    WHERE b.isEnabled = 1 AND c.bookCacheId = ? 
    ORDER BY c.chapterIndex ]], COLS_CHAPTER_UI) .. (is_desc_sort and "DESC;" or "ASC;")

    local result = self:execute(sql_stmt, bookCacheId)
    local chapters = {}
    if result then
        for i = 1, #result do
            chapters[i] = _mapChapterRowUI(result[i])
        end
    end

    return chapters
end

function M:getChapterCount(bookCacheId)
    if not H.is_str(bookCacheId) then
        return 0
    end
    local sql_stmt = "SELECT count(*) as total_num FROM chapters WHERE bookCacheId = ?;"
    local result = self:execute(sql_stmt, {bookCacheId})
    if result and result[1] and result[1][1] then
        return tonumber(result[1][1])
    end
    return 0
end

function M:getLastReadChapter(bookCacheId)
    if not H.is_str(bookCacheId) then
        return 0
    end
    local sql_stmt = [[
        SELECT COALESCE(chapterIndex, 0) AS chapterIndex
        FROM chapters
        WHERE lastUpdated IS NOT NULL AND bookCacheId = ?
        ORDER BY lastUpdated DESC
        LIMIT 1;
    ]]
    local result = self:execute(sql_stmt, {bookCacheId})
    if result and result[1] and result[1][1] then
        return tonumber(result[1][1]) or 0
    end
    return 0
end

function M:getChapterLastUpdateTime(bookCacheId)
    if not H.is_str(bookCacheId) then
        return os.time()
    end
    local sql_stmt = "SELECT lastUpdated FROM books WHERE isEnabled = 1 AND bookCacheId = ?;"
    local result = self:execute(sql_stmt, {bookCacheId})

    if result and result[1] and result[1][1] then
        return tonumber(result[1][1])
    else
        return os.time()
    end
end

function M:getChapterInfo(bookCacheId, chapterIndex)
    if not H.is_str(bookCacheId) or not H.is_num(chapterIndex) then
        dbg.log('getChapterInfo Incorrect input parameters')
        return {}
    end

    local sql_stmt = string.format([[
    SELECT %s 
    FROM chapters AS c INNER JOIN books AS b ON c.bookCacheId = b.bookCacheId 
    WHERE b.isEnabled = 1 AND c.bookCacheId = ? AND c.chapterIndex = ?;
    ]], COLS_CHAPTER_FULL)

    local result = self:execute(sql_stmt, {bookCacheId, chapterIndex})
    
    if result and #result > 0 then
        return _mapChapterRow(result[1], bookCacheId)
    end

    return {}
end

function M:getcompleteReadAheadChapters(current_chapter)

    if not H.is_tbl(current_chapter) or current_chapter.book_cache_id == nil or current_chapter.chapters_index == nil then
        dbg.log('getcompleteReadAheadChapters:', current_chapter)
        return 0
    end

    local bookCacheId = current_chapter.book_cache_id
    local current_chapters_index = current_chapter.chapters_index
    local call_event_type = current_chapter.call_event
    if call_event_type == nil then
        call_event_type = 'next'
    end

    local sql_stmt = ''
    if call_event_type == 'next' then
        sql_stmt = [[
SELECT COUNT(*) AS continuous_count
FROM chapters AS c
WHERE
  c.chapterIndex > ?
  AND c.cacheFilePath IS NOT NULL
  AND c.bookCacheId = ?
  AND c.chapterIndex < COALESCE(
      (SELECT MIN(chapterIndex)
       FROM chapters
       WHERE chapterIndex > ?
         AND cacheFilePath IS NULL
         AND bookCacheId = ?
      ),
      (SELECT MAX(chapterIndex) + 1
       FROM chapters
       WHERE bookCacheId = ?
      )
  )
  AND EXISTS (
      SELECT 1 FROM books AS b
      WHERE b.bookCacheId = c.bookCacheId
        AND b.isEnabled = 1
  );
  ]]
    else
        sql_stmt = [[
SELECT COUNT(*) AS continuous_count
FROM chapters AS c
WHERE
  c.chapterIndex < ?
  AND c.cacheFilePath IS NOT NULL
  AND c.bookCacheId = ?
  AND c.chapterIndex > COALESCE(
      (SELECT MAX(chapterIndex)
       FROM chapters
       WHERE chapterIndex < ?
         AND cacheFilePath IS NULL
         AND bookCacheId = ?
      ),
      (SELECT MIN(chapterIndex) - 1
       FROM chapters
       WHERE bookCacheId = ?
      )
  )
  AND EXISTS (
      SELECT 1 FROM books AS b
      WHERE b.bookCacheId = c.bookCacheId
        AND b.isEnabled = 1
  );
    ]]
    end
    local params = {current_chapters_index, bookCacheId, current_chapters_index, bookCacheId, bookCacheId}
    local result = self:execute(sql_stmt, params)

    if result and result[1] and result[1][1] then
        return tonumber(result[1][1])
    end
    return 0
end

function M:findChapterNotDownLoadLittle(current_chapter, count)
    if not H.is_tbl(current_chapter) or current_chapter.book_cache_id == nil or current_chapter.chapters_index == nil then
        dbg.log('findChapterNotDownLoadLittle:', current_chapter)
        return {}
    end

    if not H.is_num(count) or count < 1 then
        count = 1
    end

    local bookCacheId = current_chapter.book_cache_id
    local current_chapters_index = current_chapter.chapters_index
    local call_event_type = current_chapter.call_event
    if call_event_type == nil then
        call_event_type = 'next'
    end

    local sql_stmt = string.format([[
        SELECT %s
        FROM chapters AS c
        INNER JOIN books AS b
            ON c.bookCacheId = b.bookCacheId
        WHERE
             c.bookCacheId = ? AND b.isEnabled = 1 AND c.isRead = 0 AND c.cacheFilePath IS NULL
             ]], COLS_CHAPTER_NOT_DOWNLOADED)

    local suffix = "  AND c.chapterIndex > ?  ORDER BY c.chapterIndex ASC LIMIT "

    if call_event_type ~= 'next' then
        suffix = "  AND c.chapterIndex < ? ORDER BY c.chapterIndex DESC LIMIT "
    end

    sql_stmt = table.concat({sql_stmt, suffix, count, ';'})

    local result = self:execute(sql_stmt, {bookCacheId, current_chapters_index})

    local chapters = {}
    if result then
        for i = 1, #result do
            chapters[i] = _mapChapterNotDownloadedRow(result[i], bookCacheId)
        end
    end

    return chapters

end

function M:findNextChapterInfo(current_chapter, is_downloaded)
    if not H.is_tbl(current_chapter) or current_chapter.book_cache_id == nil or current_chapter.chapters_index == nil then
        dbg.log('findNextChapterInfo:', current_chapter)
        return {}
    end

    local bookCacheId = current_chapter.book_cache_id
    local current_chapters_index = current_chapter.chapters_index
    local call_event_type = current_chapter.call_event
    if call_event_type == nil then
        call_event_type = 'next'
    end

    local sql_stmt = string.format([[
        SELECT %s 
        FROM chapters AS c INNER JOIN books AS b ON c.bookCacheId = b.bookCacheId 
        WHERE c.bookCacheId = ? AND b.isEnabled = 1 ]], COLS_CHAPTER_FULL)

    if is_downloaded == false then
        sql_stmt = sql_stmt .. ' AND c.cacheFilePath IS NULL '
    elseif is_downloaded == true then
        sql_stmt = sql_stmt .. ' AND c.cacheFilePath IS NOT NULL '
    end

    local suffix = "  AND c.chapterIndex > ?  ORDER BY c.chapterIndex ASC LIMIT 1;"
    if call_event_type ~= 'next' then
        suffix = "  AND c.chapterIndex < ? ORDER BY c.chapterIndex DESC LIMIT 1;"
    end

    sql_stmt = sql_stmt .. suffix

    local result = self:execute(sql_stmt, {bookCacheId, current_chapters_index})

    if result and #result > 0 then
        return _mapChapterRow(result[1], bookCacheId)
    end

    return {}
end

function M:updateIsRead(chapter, isRead, is_update_timestamp)
    local bookCacheId = chapter.book_cache_id
    local chapterIndex = chapter.chapters_index
    if not H.is_str(bookCacheId) or not H.is_num(chapterIndex) then
        return
    end
    chapter.isRead = isRead
    local update_state = {}
    update_state.isRead = isRead
    if is_update_timestamp == true then
        update_state.lastUpdated = {
            _set = "= strftime('%s', 'now')"
        }
    end
    return self:dynamicUpdateChapters(chapter, update_state)
end

function M:updateCacheFilePath(chapter, cacheFilePath)

    local cacheFilePath_add = ''
    if type(cacheFilePath) == 'string' then
        cacheFilePath_add = cacheFilePath
    else
        cacheFilePath_add = self.nil_object()
    end

    return self:dynamicUpdateChapters(chapter, {
        cacheFilePath = cacheFilePath_add
    })
end

function M:isDownloaded(bookCacheId, chapterIndex)
    if not H.is_str(bookCacheId) or not H.is_num(chapterIndex) then
        return false
    end
    local sql_stmt = [[
        SELECT 1 
        FROM chapters
        WHERE bookCacheId = ?
          AND chapterIndex = ? AND cacheFilePath IS NOT NULL;
    ]]
    local result = self:execute(sql_stmt, {bookCacheId, chapterIndex})
    return result and #result > 0 and result[1][1] == 1
end

function M:disableBookShelf(bookShelfId)
    if not H.is_str(bookShelfId) then
        dbg.log('DB disableBookShelf error')
        return false
    end

    self:dynamicUpdate('books', {
        isEnabled = 0
    }, {
        bookShelfId = bookShelfId
    })
    return true
end

function M:clearBook(bookShelfId, bookCacheId)

    if not H.is_str(bookShelfId) or not H.is_str(bookCacheId) then
        dbg.log('DB clearBook error')
        return false
    end

    local update_book_sql = "UPDATE books SET isEnabled = 0 WHERE bookCacheId = ?"
    local del_chapters_sql = "DELETE FROM chapters WHERE bookCacheId = ?"
    return self:transaction(function()
        self:execute(del_chapters_sql, {bookCacheId})
        self:execute(update_book_sql, {bookCacheId})
        return true
    end, {
        enable_savepoint = false
    })()
end

function M:dynamicUpdateChapters(chapter, updateData)
    if not H.is_tbl(updateData) or not H.is_tbl(chapter) then
        dbg.log('dynamicUpdateChapters Required parameter error')
        return
    end

    local bookCacheId = chapter.book_cache_id
    local chapterIndex = chapter.chapters_index

    if not H.is_str(bookCacheId) or not H.is_num(chapterIndex) then
        dbg.log('dynamicUpdateChapters Required parameter error')
        error('dynamicUpdateChapters Required parameter error')
        return
    end

    return self:dynamicUpdate('chapters', updateData, {
        bookCacheId = bookCacheId,
        chapterIndex = chapterIndex
    })

end

function M:dynamicUpdateBooks(book, updateData)
    if not H.is_tbl(updateData) or not H.is_tbl(book) then
        dbg.log('dynamicUpdateBooks An error occurred when calling the parameter')
        return
    end

    local bookCacheId = book.book_cache_id
    local bookShelfId = book.bookShelfId

    if not H.is_str(bookCacheId) or not H.is_str(bookShelfId) then
        dbg.log('dynamicUpdateBooks Error parameters')
        error('dynamicUpdateBooks Error parameters')
        return
    end

    return self:dynamicUpdate('books', updateData, {
        bookCacheId = bookCacheId,
        bookShelfId = bookShelfId
    })
end

function M:dynamicUpdate(tableName, updateData, conditions)
    if not H.is_tbl(updateData) or not H.is_str(tableName) then
        error('Error entering necessary parameters')
        return
    end

    local set_clause = {}
    local params = {}
    local param_count = 0

    for key, value in pairs(updateData) do
        if value == '_NULL' then
            table.insert(set_clause, string.format("%s = ?", key))
            table.insert(params, self.nil_object())
        elseif H.is_tbl(value) and H.is_str(value._set) then
            table.insert(set_clause, table.concat({key, ' ', value._set}))
        else
            table.insert(set_clause, string.format("%s = ?", key))
            table.insert(params, value)
        end
        param_count = param_count + 1
    end

    if param_count < 1 then
        return
    end

    local where_clause = ""
    if H.is_tbl(conditions) then
        local where_parts = {}
        for field, value in pairs(conditions) do
            if value == '_NULL' then
                table.insert(where_parts, string.format("%s IS NULL", field))
            elseif H.is_tbl(value) and H.is_str(value._where) then
                table.insert(where_parts, table.concat({field, ' ', value._where}))
            else
                table.insert(where_parts, string.format("%s = ?", field))
                table.insert(params, value)
            end
        end

        if #where_parts > 0 then
            where_clause = " WHERE " .. table.concat(where_parts, " AND ")
        else
            return
        end

    end

    local sql_stmt = table.concat({"UPDATE ", tableName, " SET ", table.concat(set_clause, ", "), where_clause})

    -- logger.info(sql_stmt)
    return self:execute(sql_stmt, params)
end

function M:resortBooksByLastRead(bookShelfId)
    if not H.is_str(bookShelfId) then
        dbg.log('DB resortBooksByLastRead error: invalid bookShelfId')
        return false
    end
    -- app unread books durChapterTime = 0
    local sql_stmt = [[
        UPDATE books
        SET sortOrder = durChapterTime
        WHERE bookShelfId = ? AND sortOrder != 0 AND isEnabled = 1 AND durChapterTime > 1000000000;
    ]]
    return self:execute(sql_stmt, {bookShelfId})
end

function M:setBooksTopStatus(bookShelfId, book_cache_id, current_sort_order, isPinnedByTime)
    if not (H.is_str(bookShelfId) and H.is_str(book_cache_id)) then
        dbg.log('DB setBooksTopStatus error: invalid parameters')
        return false
    end

     -- 手动置顶 (优先)
    if current_sort_order ~= nil then
        if current_sort_order ~= 0 then
            return self:dynamicUpdate('books', {
                sortOrder = 0
            }, {
                bookCacheId = book_cache_id,
                bookShelfId = bookShelfId
            })
        else
            -- 如果当前排序是 0, 则取消手动置顶
            return self:dynamicUpdate('books', {
                sortOrder = {
                    _set = "= durChapterTime"
                }
            }, {
                bookCacheId = book_cache_id,
                bookShelfId = bookShelfId,
                -- 只对当前被置顶的书籍（手动或按时间）进行操作
                sortOrder = {
                    _where = '!= durChapterTime'
                }
            })
        end
    elseif isPinnedByTime == true then
         -- 按打开书籍目录时间置顶, 无需取消 
         -- 检查是否已经是最新阅读的书，避免不必要的写入
        local sql_stmt = [[
            SELECT bookCacheId FROM books 
            WHERE isEnabled = 1 AND bookShelfId = ? AND sortOrder > 0 
            ORDER BY sortOrder DESC LIMIT 1;
        ]]
        local result = self:execute(sql_stmt, {bookShelfId})
        if result and result[1] and result[1][1] and result[1][1] == book_cache_id then
            -- 如果已经是第一本
            return true
        end
        return self:dynamicUpdate('books', {
            sortOrder = {
                _set = "= CAST(ROUND((julianday('now') - 2440587.5) * 86400000) AS INTEGER)"
            }
        }, {
            bookCacheId = book_cache_id,
            bookShelfId = bookShelfId
        })
    end
end

function M:disableAllBookShelves()
    return self:getDB():exec("UPDATE books SET isEnabled = 0;")
end

function M:removeBookShelf(bookShelfId)
    if not H.is_str(bookShelfId) then
        return false
    end
    local perform_delete = self:transaction(function(targetShelfId)
        local delete_chapters_sql = [[
            DELETE FROM chapters 
            WHERE bookCacheId IN (
                SELECT bookCacheId 
                FROM books 
                WHERE bookShelfId = ?
            )
        ]]
        self:execute(delete_chapters_sql, {targetShelfId})
        local delete_books_sql = "DELETE FROM books WHERE bookShelfId = ?"
        self:execute(delete_books_sql, {targetShelfId})
        return true 
    end)
    return perform_delete(bookShelfId)
end

return M
